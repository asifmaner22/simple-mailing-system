package demo.ims2.pkg;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class Login extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement st;
	PrintWriter out;
	ResultSet rs;
	boolean b=false;
	public void init(ServletConfig sc)throws ServletException
	{
		try
		{
			super.init(sc);
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ims1?rewriteBatchedStatements=true&relaxAutoCommit=true","root","root1");
			//Connection con = ConnectionManager.getInstance().getConnection();
			st=con.createStatement();
		}catch(Exception e){System.out.println(e.toString());}
	}
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{ 
	   try
		{
 		res.setContentType("text/html");
		out=res.getWriter();
		String u=req.getParameter("una");
		String p=req.getParameter("pwd");
		if((u.equals("admin")) && (p.equals("admin")))
		    {
			    Cookie cook1=new Cookie("signin","Admin");			   
			    res.addCookie(cook1);
			    res.sendRedirect("Admin");
		    }
		System.out.println("in the service " +u);
		rs=st.executeQuery("select pwd from mailusers where uname='"+u+"'"); 
		if(rs.next())
		{
			String pwd=rs.getString(1);
			if(pwd.equals(p))
			{
					System.out.println("in the service in password");
				Cookie cook=new Cookie("signin",u);
				res.addCookie(cook);
				//res.sendRedirect("http://localhost:8080/inbox.html");
				out.println("<h1>Welcome "+u+" </h1> Go to Your <a href='inbox.html'> inbox");
				res.setHeader("Refresh","2;url=inbox.html");
			}
			else{
				out.println("Type correct password Goback <a href='login.html'> Login");
				res.setHeader("Refresh","1;url=login.html");
				
			}
		}
		else{
			out.println("<h1>Invalid user Name,press back button and try again....</h1>");
			res.setHeader("Refresh","1;url=login.html");
		}
		    
		}catch(Exception e)
		{out.println("Error"+e.toString());}
		
		
	}
}