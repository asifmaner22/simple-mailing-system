package demo.ims2.pkg;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
public class deletemail extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connection con;
	ResultSet rs=null;
	Statement st;
	PrintWriter out;
	public void init(ServletConfig sc)throws ServletException
	{
	try
	{
		super.init(sc);
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ims1?rewriteBatchedStatements=true&relaxAutoCommit=true","root","root1");
		st=con.createStatement();
	}catch(Exception e)
		{System.out.println(e.toString());}
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	try
	{
		res.setContentType("text/html");
		out=res.getWriter();
		String una=null;
		Cookie[] c = req.getCookies();
		if(c!=null)
		{
		for(int i=0;i<c.length;i++)
		{
			if(c[i].getName().equals("signin"))
			{
			una=c[i].getValue();
			break;
			}
		}
	//Deleting the unwanted mails
		Enumeration names = req.getParameterNames();
		StringTokenizer str; 	
         	while(names.hasMoreElements())
         	{
           	String name = (String)names.nextElement();
           	String value = req.getParameter(name);
	        if(value.equals("on"))
		      {
		     str=new StringTokenizer(name,"|");
		     while(str.hasMoreTokens())
			   {
			     String mfrom=str.nextToken();
			     String mdat=str.nextToken();
			     String del="update "+una+" set deleted=1 where msgfrom='"+mfrom+"' and msgdate='"+mdat+"' ";
			     st.executeUpdate(del);
			     con.commit();

			}
		}
	}
	
	//Remaining mails
        java.util.Date d = new java.util.Date();
        SimpleDateFormat d1 = new SimpleDateFormat("dd MMMM yyyy  hh:mm:ss");		
		String mailsel="select msgfrom,subject,msgdate from "+una+" where deleted=0";
		rs=st.executeQuery(mailsel);
		//res.setHeader("Refresh","5;");
		out.println("<html><BODY BGCOLOR=LightCyan ><form action='deletemail' method=post><h2>Welcome <FONT COLOR=PINK>"+una+"@myMail.com </FONT></h2><h3 align=right>"+d1.format(d)+"</h3>");
		out.println("<h3>Messages in inbox</h3><TABLE BORDER=1><TR><TH>Check</TH><TH>From</TH><TH>Subject</TH><TH>Date</TH></TR>");
		while(rs.next())
		 {	
			String from=rs.getString(1);
			String sub=rs.getString(2);
			String dat=rs.getString(3);
			out.println("<TR><TD><INPUT TYPE=CHECKBOX NAME="+from+"|"+dat+">");
			out.println("<TD width=200 align=center><A href=getmsg?msgf="+from+"&msgd="+dat+" target=rightf>"+from+"</A>");
			out.println("<TD width=200 align=center>"+sub+"<TD width=200 align=center>"+dat+"</TR>");
		}
		out.println("</Table><p><input type=submit name=b1 value=Delete></form></BODY>");
		}
	}catch(Exception e)
		{out.println(e.toString());}
	}
}