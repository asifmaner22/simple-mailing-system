package demo.ims2.pkg;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class setnewpass extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement st;
	PrintWriter out;
public void init(ServletConfig sc)throws ServletException
{
	try
	{
	super.init(sc);
	Class.forName("com.mysql.jdbc.Driver");
	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ims1?rewriteBatchedStatements=true&relaxAutoCommit=true","root","root1");
	st=con.createStatement();
	}catch(Exception e)
		{System.out.println(e.toString());}
}
public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
{
	try
	{
	res.setContentType("text/html");
	out=res.getWriter();
	String oldpwd=req.getParameter("oldp");
	String newpwd=req.getParameter("newp");
	String conpwd=req.getParameter("conp");
	String una=null;
	Cookie[] c = req.getCookies();
		if(c!=null){
		for(int i=0;i<c.length;i++)
		{
			if(c[i].getName().equals("signin"))
				una=c[i].getValue();
			break;
		}
	ResultSet rs=st.executeQuery("select pwd from mailusers where uname='"+una+"'");
	while(rs.next())
	{
		if(rs.getString("pwd").equalsIgnoreCase(oldpwd))
		{
			st.executeUpdate("update mailusers set pwd='"+newpwd+"' where pwd='"+oldpwd+"'");
			out.println("<html><body><h3>Your New Pasword was set successfully wants to go for <a href=inboxserver target=rightf><i> Inbox </i></a></body></html>");
			res.setHeader("Refresh","2;url=inboxserver");
			break;
		}
		else {
			out.println("Invalid password");
			res.setHeader("Refresh","2;url=changepass.html");
		}
		
	}
	}
	}catch(Exception e)
		{out.println(e.toString());}
}
}
