package demo.ims2.pkg;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.sql.*;
public class getmsg extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connection con;
	Statement st;
	PrintWriter out;
	ResultSet rs;
	boolean b=false;
	public void init(ServletConfig sc)throws ServletException
	{
		try
		{
			super.init(sc);
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ims1?rewriteBatchedStatements=true&relaxAutoCommit=true","root","root1");
			st=con.createStatement();
		}catch(Exception e){System.out.println(e.toString());}
	}
	public void service(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{ 
		try
		{
 		res.setContentType("text/html");
 		
		out=res.getWriter();
		out.println("<html><BODY BGCOLOR=LightCyan >");
		String mfrom=req.getParameter("msgf");
		String mdate=req.getParameter("msgd");
		
		String una=null;
		Cookie[] c = req.getCookies();
		if(c!=null)
		{
		for(int i=0;i<c.length;i++)
		{
			if(c[i].getName().equals("signin"))
				una=c[i].getValue();
			break;
		}

		String selst="select * from "+una+" where msgfrom='"+mfrom+"' and msgdate='"+mdate+"'";
		rs=st.executeQuery(selst);
		while(rs.next())
		{
			out.println("<a href=inboxserver target=rightf>Inbox</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href=deletemail target=rightf>Delete</a><p>");
			out.println("<body><table BORDER=1><tr><td align=right width=110> Message From  :<td width=200>"+rs.getString(1));
			out.println("<tr><td align=right width=110> Subject : <td width=200>"+rs.getString(2));
			out.println("<tr><td align=right width=110> DateTime : <td width=200>"+rs.getString(4)+"</table>");
			//out.println("<h4><i>"+mfrom+"</i> Wrote </h4><br>"+rs.getString(3));
			out.println("<table BORDER=1 ><tr><td width=500 hight=200> Msg : "+rs.getString(3)+"</table>");
			//out.println("<p><a href=inboxserver target=rightf>Inbox</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href= target=rightf>Next</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href= target=rightf>Previous</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href= target=rightf>Reply</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href= target=rightf>Reply all</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href= target=rightf>Delete</a>");
		}
		
		out.println("</BODY></html>");
		}
		
	}catch(Exception e)
		{out.println(e.toString());}
	}
}
