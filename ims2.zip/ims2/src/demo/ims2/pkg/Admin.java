package demo.ims2.pkg;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.*;
import java.sql.*;
import java.util.*;
public class Admin extends HttpServlet
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Connection con;
	ResultSet rs=null;
	Statement st;
	ResultSet rs1=null;
	Statement st1;
	PrintWriter out;
	public void init(ServletConfig sc)throws ServletException
	{
	try
	{
		super.init(sc);
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ims1?rewriteBatchedStatements=true&relaxAutoCommit=true","root","root1");
		st=con.createStatement();
		st1=con.createStatement();
	}catch(Exception e)
		{System.out.println(e.toString());}
	}
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException
	{
	try
	{
		String a1=null;
		Cookie[] c = req.getCookies();
		if(c!=null)
		for(int i=0;i<c.length;i++)
		{
			if(c[i].getName().equals("signin"))
			{
				a1=c[i].getValue();
				break;
			}
		}
		
		
		if(a1.equals("Admin"))
		{		
		
		res.setContentType("text/html");
		out=res.getWriter();
		out.println("<html><BODY BGCOLOR=SeaShell><form action='Admin' method=post><h2>"+a1+"Welcome <FONT COLOR=HotPink>Admin@myMail.com </FONT></h2>");	
		out.println("<a href=logout >Logout</a> Admin");
		out.println("<a href=uAdmin >User</a> uAdmin");
		out.println("<h3>Messages in Log</h3><TABLE BORDER=1><TR><TH>Check</TH><TH>To</TH><TH>From</TH><TH>Subject</TH><TH>Date</TH><TH>Message</TH><TH>isDeleted</TH></TR>");
		
		String mailusers="select uname from mailusers";
		rs1=st1.executeQuery(mailusers);
		while(rs1.next())
		{
	      String una=rs1.getString(1);
		  String mailsel="select msgfrom,subject,msgdate,msg,deleted from "+una+" order by msgdate";
		  rs=st.executeQuery(mailsel);		  		  
		  while(rs.next())
		   {	
			  String from=rs.getString(1);
			  String sub=rs.getString(2);
			  String dat=rs.getString(3);
			  String msg=rs.getString(4);
			  String del=rs.getString(5);
			  out.println("<TR><TD><INPUT TYPE=CHECKBOX NAME="+una+"|"+from+"|"+dat+">");
			  out.println("<TD width=200 align=center>"+una+"<TD width=200 align=center>"+from+"");
			  out.println("<TD width=200 align=center>"+sub+"<TD width=200 align=center>"+dat+"<TD width=200 align=center>"+msg+"<TD width=200 align=center>"+del+"</TR>");
		    }
		
		  }
		out.println("</Table><p><input type=submit name=b1 value=Delete></form></BODY></html>");
		
	
	
		
		
		
		
		Enumeration names = req.getParameterNames();
		StringTokenizer str; 	
         	while(names.hasMoreElements())
         	{
           	String name = (String)names.nextElement();
           	String value = req.getParameter(name);
	        if(value.equals("on"))
		      {
		     str=new StringTokenizer(name,"|");
		     while(str.hasMoreTokens())
			   {
			     String user=str.nextToken();
			     String mfrom=str.nextToken();
			     String mdat=str.nextToken();
			     String del="delete from "+user+" where msgfrom='"+mfrom+"' and msgdate='"+mdat+"' ";
			     st.executeUpdate(del);
			     con.commit();

			}
		     res.sendRedirect("Admin");
		}
	}
         	
		
	
		}
		else
			res.sendRedirect("login.html");
		
	
	}
	catch(Exception e)
		{out.println(e.toString());}
	}
}